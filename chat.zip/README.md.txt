{
  "name": "secret-chat-server",
  "version": "1.0.0",
  "description": "두 명만 쓰는 비밀 채팅 서버",
  "main": "server.js",
  "scripts": {
    "start": "node server.js"
  },
  "dependencies": {
    "express": "^4.18.2"
  }
}